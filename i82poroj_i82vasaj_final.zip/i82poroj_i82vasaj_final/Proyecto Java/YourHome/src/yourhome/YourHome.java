/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yourhome;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.util.Locale;
import java.util.ResourceBundle;
import yourhome.dispositivos.*;
import yourhome.habitaciones.*;

/**
 *
 * @author usuario
 */
public class YourHome {

    public static ResourceBundle bundle_text;
    public static Locale currentLocale;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        if(args.length!=0){
            if(args[0].compareTo("en")==0){
                currentLocale=new Locale("en","GB");
            }
            else if(args[0].compareTo("fr")==0){
                currentLocale=new Locale("fr","FR");
            }
            
        }
        else{
            currentLocale=Locale.getDefault();

        }

        bundle_text = ResourceBundle.getBundle("bundle/Bundle", currentLocale);
        new Home_Frame().setVisible(true);
    } 
        
    
    
}
