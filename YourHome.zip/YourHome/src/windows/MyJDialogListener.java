package windows;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * Listener para el ejemplo de JDialog
 * 
 * @author Jose M. Moyano
 */
public class MyJDialogListener implements ActionListener{
    JFrame jf;
    
    public MyJDialogListener(JFrame cp) {
        this.jf = cp;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        JDialog dialog = new JDialog(jf, "Ventana secundaria");
        
        JPanel jp = new JPanel(new FlowLayout());
        jp.add(new JLabel("Esta ventana es secundaria."));
        jp.add(new JButton("OK"));
        jp.setVisible(true);
        
        dialog.setContentPane(jp);
        dialog.setSize(400, 150);
        dialog.setVisible(true);
        
    }
}
