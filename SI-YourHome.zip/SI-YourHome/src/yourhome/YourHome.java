package yourhome;

//import javax.swing.JFrame;
//import javax.swing.JPanel;
//import ejemplos.Inter_Frame;

/**
 *
 * @author usuario
 */
public class YourHome {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    }
    
}
