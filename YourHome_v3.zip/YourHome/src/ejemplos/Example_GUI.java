package ejemplos;

import javax.swing.*;
import java.awt.*;

/**
 * Primera GUI en Java Swing
 * 
 * @author Jose M. Moyano
 *
 */
public class Example_GUI {
  public static void main(String[] args) {
    JFrame jf = new JFrame("Título de ventana");
            
    jf.setSize(400, 300);
    jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    jf.setVisible(true);
  }
}


