package windows;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

/**
 * Listener para botón
 * Modifica el texto del botón original por "Pulsado!"
 * 
 * @author Jose M. Moyano
 *
 */
public class MyButtonListener implements ActionListener{
    
    @Override
    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton)e.getSource();
        button.setText("Pulsado!");
    }

}
