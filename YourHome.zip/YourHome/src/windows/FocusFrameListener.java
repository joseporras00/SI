package windows;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JDialog;
import javax.swing.JFrame;

/**
 * Listener para volver al JFrame principal al cerrar el JDialog
 * 
 * @author Jose M. Moyano
 */
public class FocusFrameListener extends WindowAdapter{
    
    JFrame main_frame;
    JDialog dialog;
    
    public FocusFrameListener(JFrame main_frame, JDialog dialog){
        this.main_frame = main_frame;
        this.dialog = dialog;
    }
    
    public void windowClosing(WindowEvent e) {
        main_frame.setVisible(true);
        dialog.setVisible(false);
    }
    
    public void windowClosed(WindowEvent e) {
        main_frame.setVisible(true);
        dialog.setVisible(false);
    }
}
