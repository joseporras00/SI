package ejemplos;

import javax.swing.*;
import java.awt.*;

/**
 * Ejercicio 3 del tutorial de Java Swing
 * 
 * @author Jose M. Moyano
 *
 */
public class Exercise3 {
  public static void main(String[] args) {
    JFrame jf = new JFrame("Ejercicio 3");
    
    FlowLayout fl = new FlowLayout();

    //Alineación de los elementos
    fl.setAlignment(FlowLayout.CENTER);

    //Espaciado entre elementos
    fl.setHgap(5);
    fl.setVgap(5);
    
    JPanel jp = new JPanel(fl);
    
    JLabel label = new JLabel("Original");
    jp.add(label);
    
    
    JTextField textField = new JTextField(10);
    jp.add(textField);
    
    JButton button = new JButton("Enviar");
    button.addActionListener(new Exercise3_ButtonListener(label, textField));
    jp.add(button);
    
    jf.add(jp);
        
    jf.setSize(300, 100);
    jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    jf.setVisible(true);
  }
}


