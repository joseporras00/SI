package ejemplos;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 * Listener para mostrar un JDialog por defecto
 * 
 * @author Jose M. Moyano
 */
public class MessageDialogListener implements ActionListener{
    Container cp;
    
    public MessageDialogListener(Container cp) {
        this.cp = cp;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(cp, "Ha ocurrido un error", "Error!",
                JOptionPane.WARNING_MESSAGE);
    }
}
