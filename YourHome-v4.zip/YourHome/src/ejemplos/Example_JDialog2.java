package ejemplos;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

/**
 * Ejemplo de JDialog. EL JFrame principal se esconde mientras que el JDialog 
 * está activo.
 * 
 * @author Jose M. Moyano
 * http://chuwiki.chuidiang.org/index.php?title=JFrame_y_JDialog
 */
public class Example_JDialog2 {

	private JFrame jf;
	private JDialog jd;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Example_JDialog2();
	}
	
	public Example_JDialog2()
	{
		// Construcción de ventana principal
		jf = new JFrame("Main window");
		JButton boton = new JButton("Open JDialog");
		jf.getContentPane().add(boton);
		jf.pack();
		
		// Construcción de ventana secundaria
		jd = new JDialog(jf,"My secondary window");
		JLabel etiqueta = new JLabel("My JDialog");
		jd.getContentPane().add(etiqueta);
		jd.pack();

		// Hacer que el botón abra la ventana secundaria y cierre la
		// principal
		boton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jf.setVisible(false);
				jd.setVisible(true);
			}
		
		});
		
		// Hacer que al cerrarse la secundaria con la x de arriba a la
		// derecha, se muestre la primaria
		jd.addWindowListener(new FocusFrameListener(jf, jd));
		
		// Mostrar la ventana principal
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		jf.setVisible(true);
	}

}
