package windows;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 * Listener para botón del ejercicio 3
 * 
 * @author Jose M. Moyano
 *
 */
public class Exercise3_ButtonListener implements ActionListener{
    
    JLabel label;
    JTextField text;
    
    public Exercise3_ButtonListener(JLabel label, JTextField text) {
        this.label = label;
        this.text = text;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        label.setText(text.getText());
    }
}
